/*
 * PPM_Capture.h
 *
 *  Created on: Mar 1, 2017
 *      Author: Tyler
 */

#pragma once
#ifndef PPM_INIT_H_
#define PPM_INIT_H_

#include "project_types.h"


void TIMER_Initialize(void);

void capture_pos_fxn();

void capture_neg_fxn();

void capture_pos_fxn2();

void capture_neg_fxn2();
#endif /* PPM_INIT_H_ */
